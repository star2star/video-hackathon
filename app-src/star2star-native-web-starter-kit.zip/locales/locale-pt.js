"use strict";
const messages = {
  'AUDIOCONTROLS-INPUT-HEADING': 'Entrada',
};
module.exports = messages;
