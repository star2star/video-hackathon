"use strict";
const messages = {
  'AUDIOCONTROLS-INPUT-HEADING': 'Ingresso',
};
module.exports = messages;
