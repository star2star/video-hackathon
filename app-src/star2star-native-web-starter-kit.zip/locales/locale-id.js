"use strict";
const messages = {
  'AUDIOCONTROLS-INPUT-HEADING': 'Memasukkan',
};
module.exports = messages;
