"use strict";
const messages = {
  'AUDIOCONTROLS-INPUT-HEADING': 'Input',
};
module.exports = messages;
