"use strict";
const messages = {
  'AUDIOCONTROLS-INPUT-HEADING': 'вход',
};
module.exports = messages;
