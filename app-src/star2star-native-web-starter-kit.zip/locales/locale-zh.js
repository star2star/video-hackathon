"use strict";
const messages = {
  'AUDIOCONTROLS-INPUT-HEADING': '输入',
};
module.exports = messages;
