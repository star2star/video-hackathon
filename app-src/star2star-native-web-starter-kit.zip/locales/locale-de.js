"use strict";
const messages = {
  'AUDIOCONTROLS-INPUT-HEADING': 'Eingang',
};
module.exports = messages;
