"use strict";
const messages = {
  'AUDIOCONTROLS-INPUT-HEADING': 'Ingång',
};
module.exports = messages;
