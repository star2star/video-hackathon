"use strict";
const messages = {
  'AUDIOCONTROLS-INPUT-HEADING': 'Contribution',
  };
module.exports = messages;
