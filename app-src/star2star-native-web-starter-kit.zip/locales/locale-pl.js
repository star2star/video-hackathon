"use strict";
const messages = {
  'AUDIOCONTROLS-INPUT-HEADING': 'Wkład',
};
module.exports = messages;
